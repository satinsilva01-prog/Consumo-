package com.combio.v32;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.GeolocationPermissions;
import android.content.Intent;
import android.Manifest;
import android.net.Uri;
import android.os.Environment;
import androidx.core.content.FileProvider;
import java.io.File;

public class MainActivity extends Activity {
    private WebView w;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraOutputUri;
    private static final int FILE_CHOOSER_REQUEST = 2001;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);

        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        // Mantém o serviço de operação ativo quando a tela é apagada.
        try {
            Intent serviceIntent = new Intent(this, ComBioBackgroundService.class);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                startForegroundService(serviceIntent);
            } else {
                startService(serviceIntent);
            }
        } catch (Exception ignored) {
        }

        w = new WebView(this);
        w.setWebViewClient(new WebViewClient());

        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setGeolocationEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);

        w.addJavascriptInterface(new AndroidBridge(), "Android");

        w.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(
                    String origin,
                    GeolocationPermissions.Callback callback) {
                callback.invoke(origin, true, false);
            }

            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> callback,
                    FileChooserParams params) {

                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }

                filePathCallback = callback;

                try {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                    if (dir != null && !dir.exists()) {
                        dir.mkdirs();
                    }

                    File photo = File.createTempFile(
                            "combio_photo_",
                            ".jpg",
                            dir
                    );

                    cameraOutputUri = FileProvider.getUriForFile(
                            MainActivity.this,
                            getPackageName() + ".fileprovider",
                            photo
                    );

                    Intent camera = new Intent(
                            android.provider.MediaStore.ACTION_IMAGE_CAPTURE
                    );

                    camera.putExtra(
                            android.provider.MediaStore.EXTRA_OUTPUT,
                            cameraOutputUri
                    );

                    camera.addFlags(
                            Intent.FLAG_GRANT_READ_URI_PERMISSION |
                            Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    );

                    startActivityForResult(
                            camera,
                            FILE_CHOOSER_REQUEST
                    );

                    return true;

                } catch (Exception e) {

                    Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("image/*");

                    startActivityForResult(
                            Intent.createChooser(
                                    pick,
                                    "Selecionar imagem"
                            ),
                            FILE_CHOOSER_REQUEST
                    );

                    return true;
                }
            }
        });

        setContentView(w);

        if (android.os.Build.VERSION.SDK_INT >= 23) {
            requestPermissions(
                    new String[]{
                            Manifest.permission.CAMERA,
                            Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    },
                    100
            );
        }

        w.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data) {

        super.onActivityResult(
                requestCode,
                resultCode,
                data
        );

        if (requestCode == FILE_CHOOSER_REQUEST &&
                filePathCallback != null) {

            Uri[] results = null;

            if (resultCode == RESULT_OK) {
                if (data != null && data.getData() != null) {
                    results = new Uri[]{data.getData()};
                } else if (cameraOutputUri != null) {
                    results = new Uri[]{cameraOutputUri};
                }
            }

            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
            cameraOutputUri = null;
        }
    }

    public class AndroidBridge {

        @JavascriptInterface
        public void shareText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("text/plain");
                        send.putExtra(
                                Intent.EXTRA_TEXT,
                                text == null ? "" : text
                        );
                        send.putExtra(
                                Intent.EXTRA_TITLE,
                                "ComBio Energia"
                        );

                        Intent chooser = Intent.createChooser(
                                send,
                                "Compartilhar ComBio"
                        );

                        startActivity(chooser);

                    } catch (Exception e) {
                        try {
                            Intent send = new Intent(Intent.ACTION_SEND);
                            send.setType("text/plain");
                            send.putExtra(
                                    Intent.EXTRA_TEXT,
                                    text == null ? "" : text
                            );

                            startActivity(
                                    Intent.createChooser(
                                            send,
                                            "Compartilhar"
                                    )
                            );

                        } catch (Exception ignored) {
                        }
                    }
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (w != null && w.canGoBack()) {
            w.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
