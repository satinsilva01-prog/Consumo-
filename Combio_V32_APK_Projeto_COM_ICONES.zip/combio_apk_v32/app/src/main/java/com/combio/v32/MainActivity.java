package com.combio.v32;
import android.app.*; import android.os.*; import android.webkit.*; import android.view.*; import android.Manifest; import android.content.pm.PackageManager;
public class MainActivity extends Activity {
 WebView w;
 @Override public void onCreate(Bundle b){super.onCreate(b); w=new WebView(this); w.setWebViewClient(new WebViewClient()); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false); s.setGeolocationEnabled(true); w.setWebChromeClient(new WebChromeClient(){@Override public void onGeolocationPermissionsShowPrompt(String o,GeolocationPermissions.Callback c){c.invoke(o,true,false);}}); setContentView(w); if(Build.VERSION.SDK_INT>=23) requestPermissions(new String[]{Manifest.permission.CAMERA,Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},100); w.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){ if(w.canGoBack()) w.goBack(); else super.onBackPressed(); }
}
